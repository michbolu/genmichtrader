
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { LineChart, ChevronDown } from "lucide-react";

interface PriceChartProps {
  symbol?: string;
  name?: string;
  data?: any[];
  isPositive?: boolean;
}

export function PriceChart({
  symbol = "BTC/USD",
  name = "Bitcoin",
  isPositive = true,
  data = [
    { time: "00:00", price: 60241 },
    { time: "04:00", price: 60584 },
    { time: "08:00", price: 59876 },
    { time: "12:00", price: 61230 },
    { time: "16:00", price: 60845 },
    { time: "20:00", price: 61567 },
    { time: "24:00", price: 61245 },
  ],
}: PriceChartProps) {
  return (
    <Card className="col-span-2">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2">
          <LineChart className="h-5 w-5" />
          <span>{symbol} - {name}</span>
        </CardTitle>
        
        <div className="flex items-center space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-8 gap-1">
                1D
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>1H</DropdownMenuItem>
              <DropdownMenuItem>4H</DropdownMenuItem>
              <DropdownMenuItem>1D</DropdownMenuItem>
              <DropdownMenuItem>1W</DropdownMenuItem>
              <DropdownMenuItem>1M</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <div className={`text-sm font-medium ${isPositive ? 'text-trading-profit' : 'text-trading-loss'}`}>
            {isPositive ? '+' : ''}1.67%
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{
                top: 10,
                right: 5,
                left: 5,
                bottom: 0,
              }}
            >
              <defs>
                <linearGradient id="chart-gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={isPositive ? 'rgb(34, 197, 94)' : 'rgb(239, 68, 68)'} stopOpacity={0.2} />
                  <stop offset="100%" stopColor={isPositive ? 'rgb(34, 197, 94)' : 'rgb(239, 68, 68)'} stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="time"
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                tickFormatter={(value) => `$${value.toLocaleString()}`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  borderColor: 'hsl(var(--border))',
                  borderRadius: '0.375rem',
                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
                }}
                labelStyle={{ color: 'hsl(var(--card-foreground))' }}
              />
              <Area
                type="monotone"
                dataKey="price"
                stroke={isPositive ? 'rgb(34, 197, 94)' : 'rgb(239, 68, 68)'}
                strokeWidth={2}
                fill="url(#chart-gradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
