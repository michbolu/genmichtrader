
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  LayoutDashboard, 
  LineChart, 
  Bot, 
  Briefcase, 
  ShieldAlert, 
  Settings,
  LogOut,
  Info
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  to: string;
  active?: boolean;
}

const NavItem = ({ icon, label, to, active = false }: NavItemProps) => (
  <Link to={to} className="w-full">
    <Button
      variant="ghost"
      className={cn(
        "w-full justify-start gap-2 px-3 text-sidebar-foreground/70 hover:text-sidebar-foreground",
        active && "bg-sidebar-accent text-sidebar-foreground"
      )}
    >
      {icon}
      <span>{label}</span>
    </Button>
  </Link>
);

export function SideNav({ activePath = "/" }: { activePath?: string }) {
  return (
    <div className="h-screen w-64 bg-sidebar flex flex-col border-r border-sidebar-border">
      <div className="p-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="font-bold text-primary-foreground">G</span>
          </div>
          <div className="font-semibold text-lg text-sidebar-foreground">Gen.Michael</div>
        </div>
      </div>
      
      <ScrollArea className="flex-1 px-3 py-2">
        <div className="space-y-1">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            to="/" 
            active={activePath === "/"} 
          />
          <NavItem 
            icon={<LineChart size={20} />} 
            label="Markets" 
            to="/markets" 
            active={activePath === "/markets"} 
          />
          <NavItem 
            icon={<Bot size={20} />} 
            label="Trading Bots" 
            to="/bots" 
            active={activePath === "/bots"} 
          />
          <NavItem 
            icon={<Briefcase size={20} />} 
            label="Portfolio" 
            to="/portfolio" 
            active={activePath === "/portfolio"} 
          />
          <NavItem 
            icon={<ShieldAlert size={20} />} 
            label="Risk Management" 
            to="/risk" 
            active={activePath === "/risk"} 
          />
        </div>
        
        <Separator className="my-4 bg-sidebar-border" />
        
        <div className="space-y-1">
          <NavItem 
            icon={<Info size={20} />} 
            label="About Us" 
            to="/about" 
            active={activePath === "/about"} 
          />
          <NavItem 
            icon={<Settings size={20} />} 
            label="Settings" 
            to="/settings" 
            active={activePath === "/settings"} 
          />
        </div>
      </ScrollArea>
      
      <div className="p-4 mt-auto">
        <Button variant="ghost" className="w-full justify-start gap-2 text-sidebar-foreground/70 hover:text-sidebar-foreground">
          <LogOut size={20} />
          <span>Logout</span>
        </Button>
      </div>
    </div>
  );
}
