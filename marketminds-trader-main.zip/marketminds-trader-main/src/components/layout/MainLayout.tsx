
import { SideNav } from "./SideNav";
import { Header } from "./Header";
import { useLocation } from "react-router-dom";

interface MainLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export function MainLayout({ children, title }: MainLayoutProps) {
  const location = useLocation();

  return (
    <div className="flex h-screen overflow-hidden">
      <SideNav activePath={location.pathname} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={title} />
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
