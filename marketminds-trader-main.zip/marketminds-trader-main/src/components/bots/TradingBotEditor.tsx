
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Bot, 
  Play, 
  Pause, 
  Save, 
  Trash2, 
  Info,
  Plus
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";

export function TradingBotEditor() {
  const { toast } = useToast();
  const [isActive, setIsActive] = useState(false);
  
  const handleSave = () => {
    toast({
      title: "Bot configuration saved",
      description: "Your trading bot configuration has been saved.",
    });
  };
  
  const handleToggleActive = () => {
    setIsActive(!isActive);
    
    toast({
      title: isActive ? "Bot paused" : "Bot activated",
      description: isActive 
        ? "Your trading bot has been paused and will not execute trades." 
        : "Your trading bot is now active and will begin executing trades based on your strategy.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          Configure Trading Bot
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bot-name">Bot Name</Label>
              <Input id="bot-name" placeholder="Momentum Trader" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="trading-pair">Asset/Pair</Label>
              <Select defaultValue="btcusd">
                <SelectTrigger id="trading-pair">
                  <SelectValue placeholder="Select trading pair" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="btcusd">BTC/USD</SelectItem>
                  <SelectItem value="ethusd">ETH/USD</SelectItem>
                  <SelectItem value="aapl">AAPL</SelectItem>
                  <SelectItem value="msft">MSFT</SelectItem>
                  <SelectItem value="eurusd">EUR/USD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="strategy">Strategy Type</Label>
              <Select defaultValue="momentum">
                <SelectTrigger id="strategy">
                  <SelectValue placeholder="Select strategy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="momentum">Momentum</SelectItem>
                  <SelectItem value="mean-reversion">Mean Reversion</SelectItem>
                  <SelectItem value="breakout">Breakout</SelectItem>
                  <SelectItem value="arbitrage">Arbitrage</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label htmlFor="position-size">
                  <div className="flex items-center gap-1.5">
                    Position Size
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="w-64 text-sm">
                            The amount of capital to allocate per trade, expressed as a percentage of your total available funds.
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </Label>
                <span className="text-sm font-medium">5%</span>
              </div>
              <Slider defaultValue={[5]} max={25} step={1} />
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label htmlFor="stop-loss">
                  <div className="flex items-center gap-1.5">
                    Stop Loss
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="w-64 text-sm">
                            Sets a percentage threshold for a losing trade at which the position will automatically be closed to limit further losses.
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </Label>
                <span className="text-sm font-medium">2%</span>
              </div>
              <Slider defaultValue={[2]} max={10} step={0.5} />
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="timeframe">Timeframe</Label>
              <Select defaultValue="1h">
                <SelectTrigger id="timeframe">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5m">5 minutes</SelectItem>
                  <SelectItem value="15m">15 minutes</SelectItem>
                  <SelectItem value="1h">1 hour</SelectItem>
                  <SelectItem value="4h">4 hours</SelectItem>
                  <SelectItem value="1d">1 day</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="custom-rules">Custom Rules (Optional)</Label>
              <Textarea 
                id="custom-rules" 
                placeholder="Enter custom trading rules or conditions..."
                className="min-h-[120px]"
              />
            </div>
            
            <div className="flex items-center space-x-2 pt-4">
              <Switch 
                id="notifications" 
                checked={true}
              />
              <Label htmlFor="notifications">Enable trade notifications</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="confirmation" 
              />
              <Label htmlFor="confirmation">Require confirmation before trades</Label>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between pt-4">
          <div className="flex gap-2">
            <Button variant="destructive" size="sm">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
            <Button variant="outline" size="sm" onClick={handleSave}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              New Bot
            </Button>
            <Button 
              variant={isActive ? "secondary" : "default"} 
              size="sm"
              onClick={handleToggleActive}
            >
              {isActive ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Activate
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
