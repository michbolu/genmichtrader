
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ShieldAlert, 
  BarChart4, 
  Sliders, 
  AlertTriangle, 
  PieChart,
  Info
} from "lucide-react";
import {
  PieChart as ReChartPie,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip as ReChartTooltip,
  Legend,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export function RiskManagementDashboard() {
  const exposureData = [
    { name: "Stocks", value: 42, color: "hsl(var(--primary))" },
    { name: "Crypto", value: 35, color: "hsl(142, 71%, 45%)" },
    { name: "Forex", value: 15, color: "hsl(262, 80%, 65%)" },
    { name: "Cash", value: 8, color: "hsl(215, 16%, 47%)" },
  ];
  
  const riskScores = [
    { name: "Market Risk", score: 68, description: "Risk associated with market price movements" },
    { name: "Volatility", score: 72, description: "Measure of price fluctuations and instability" },
    { name: "Correlation Risk", score: 45, description: "Risk from excessive correlation between positions" },
    { name: "Leverage Risk", score: 25, description: "Risk from using borrowed funds to trade" },
    { name: "Liquidity Risk", score: 30, description: "Risk of not being able to exit positions easily" },
  ];
  
  const alerts = [
    { title: "High Concentration", description: "75% of your portfolio is in technology sector", severity: "high" },
    { title: "Volatility Warning", description: "BTC/USD volatility has increased by 35% in the last 24h", severity: "medium" },
    { title: "Stop Loss Triggered", description: "Stop loss triggered for TSLA position at $187.23", severity: "medium" },
    { title: "Margin Call Warning", description: "Your margin position is approaching liquidation", severity: "high" },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="h-5 w-5" />
            Risk Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="analysis">Risk Analysis</TabsTrigger>
              <TabsTrigger value="alerts">Alerts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Total Exposure</h3>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ReChartPie>
                        <ReChartTooltip />
                        <Pie
                          data={exposureData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={2}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                        >
                          {exposureData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Legend />
                      </ReChartPie>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Risk Metrics</h3>
                  <div className="space-y-4">
                    {riskScores.map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-medium">{item.name}</span>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="w-64 text-sm">{item.description}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                          <span className="text-sm font-medium">{item.score}/100</span>
                        </div>
                        <Progress 
                          value={item.score} 
                          className="h-2"
                          indicatorClassName={
                            item.score > 65 ? "bg-trading-loss" : 
                            item.score > 40 ? "bg-orange-400" : 
                            "bg-trading-profit"
                          }
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end mt-6">
                <Button variant="outline" className="gap-2">
                  <Sliders className="h-4 w-4" />
                  Adjust Risk Parameters
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="analysis" className="pt-4">
              <div className="grid grid-cols-1 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <BarChart4 className="h-4 w-4" />
                      Portfolio Value at Risk (VaR)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <div>
                          <div className="text-sm text-muted-foreground">Daily VaR (95% confidence)</div>
                          <div className="text-2xl font-semibold">$2,345.67</div>
                          <div className="text-sm">1.5% of portfolio</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Weekly VaR (95% confidence)</div>
                          <div className="text-2xl font-semibold">$5,678.91</div>
                          <div className="text-sm">3.6% of portfolio</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Monthly VaR (95% confidence)</div>
                          <div className="text-2xl font-semibold">$11,234.56</div>
                          <div className="text-sm">7.2% of portfolio</div>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">Value at Risk (VaR) estimates the potential loss in value of your portfolio over a defined period for a given confidence interval.</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center gap-2 text-base">
                      <PieChart className="h-4 w-4" />
                      Diversification Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <div>
                          <div className="text-sm text-muted-foreground">Diversification Score</div>
                          <div className="text-2xl font-semibold text-orange-400">65/100</div>
                          <div className="text-sm">Moderate diversification</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Sector Concentration</div>
                          <div className="text-2xl font-semibold text-trading-loss">High</div>
                          <div className="text-sm">Technology: 75%</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Asset Correlation</div>
                          <div className="text-2xl font-semibold text-orange-400">Medium</div>
                          <div className="text-sm">Avg. correlation: 0.45</div>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">Diversification reduces risk by spreading investments across different assets that don't move together.</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="alerts" className="pt-4">
              <div className="space-y-4">
                {alerts.map((alert, index) => (
                  <Card key={index} className={`border-l-4 ${
                    alert.severity === 'high' ? 'border-l-trading-loss' : 'border-l-orange-400'
                  }`}>
                    <CardContent className="p-4 flex items-start justify-between">
                      <div className="flex gap-3">
                        <AlertTriangle className={`h-5 w-5 mt-0.5 ${
                          alert.severity === 'high' ? 'text-trading-loss' : 'text-orange-400'
                        }`} />
                        <div>
                          <h4 className="font-medium">{alert.title}</h4>
                          <p className="text-sm text-muted-foreground">{alert.description}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Resolve
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
