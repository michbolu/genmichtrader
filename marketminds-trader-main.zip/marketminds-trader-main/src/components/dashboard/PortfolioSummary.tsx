
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, ArrowUp, ArrowDown, DollarSign } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export function PortfolioSummary() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <LineChart className="h-5 w-5" />
          Portfolio Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-baseline justify-between">
            <h3 className="text-xl font-semibold">$156,789.42</h3>
            <div className="flex items-center text-trading-profit text-sm font-medium">
              <ArrowUp className="h-3 w-3 mr-1" />
              5.32% ($8,324)
            </div>
          </div>
          <div className="text-sm text-muted-foreground">Total portfolio value</div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <div className="font-medium">Asset Allocation</div>
            <div className="text-muted-foreground">% of portfolio</div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary"></div>
                <span className="text-sm">Stocks</span>
              </div>
              <span className="text-sm">42%</span>
            </div>
            <Progress value={42} className="h-2" />
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-trading-profit"></div>
                <span className="text-sm">Crypto</span>
              </div>
              <span className="text-sm">35%</span>
            </div>
            <Progress value={35} className="h-2 bg-muted">
              <div className="h-full bg-trading-profit rounded-full" style={{ width: '35%' }} />
            </Progress>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-trading-neutral"></div>
                <span className="text-sm">Forex</span>
              </div>
              <span className="text-sm">15%</span>
            </div>
            <Progress value={15} className="h-2 bg-muted">
              <div className="h-full bg-trading-neutral rounded-full" style={{ width: '15%' }} />
            </Progress>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-muted-foreground"></div>
                <span className="text-sm">Cash</span>
              </div>
              <span className="text-sm">8%</span>
            </div>
            <Progress value={8} className="h-2 bg-muted">
              <div className="h-full bg-muted-foreground rounded-full" style={{ width: '8%' }} />
            </Progress>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
