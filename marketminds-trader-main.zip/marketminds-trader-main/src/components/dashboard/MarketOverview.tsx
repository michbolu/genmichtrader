
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, TrendingDown, CandlestickChart } from "lucide-react";

interface MarketItemProps {
  symbol: string;
  name: string;
  price: string;
  change: string;
  changePercent: string;
  isPositive: boolean;
}

const MarketItem = ({ symbol, name, price, change, changePercent, isPositive }: MarketItemProps) => (
  <div className="flex items-center justify-between py-3">
    <div className="flex items-center gap-3">
      <div className={`w-10 h-10 rounded flex items-center justify-center ${isPositive ? 'bg-trading-profit/10' : 'bg-trading-loss/10'}`}>
        {isPositive ? 
          <TrendingUp className="h-5 w-5 text-trading-profit" /> : 
          <TrendingDown className="h-5 w-5 text-trading-loss" />
        }
      </div>
      <div>
        <div className="font-medium">{symbol}</div>
        <div className="text-muted-foreground text-sm">{name}</div>
      </div>
    </div>
    <div className="text-right">
      <div className="font-medium">{price}</div>
      <div className={`text-sm ${isPositive ? 'text-trading-profit' : 'text-trading-loss'}`}>
        {change} ({changePercent})
      </div>
    </div>
  </div>
);

export function MarketOverview() {
  const stocks = [
    { symbol: "AAPL", name: "Apple Inc.", price: "$182.63", change: "+1.45", changePercent: "0.8%", isPositive: true },
    { symbol: "MSFT", name: "Microsoft Corp.", price: "$402.75", change: "-3.21", changePercent: "0.79%", isPositive: false },
    { symbol: "GOOGL", name: "Alphabet Inc.", price: "$162.08", change: "+0.87", changePercent: "0.54%", isPositive: true },
    { symbol: "AMZN", name: "Amazon.com Inc.", price: "$178.15", change: "+2.31", changePercent: "1.31%", isPositive: true },
  ];
  
  const crypto = [
    { symbol: "BTC", name: "Bitcoin", price: "$61,245.32", change: "+1,256.78", changePercent: "2.1%", isPositive: true },
    { symbol: "ETH", name: "Ethereum", price: "$3,432.17", change: "-45.32", changePercent: "1.30%", isPositive: false },
    { symbol: "BNB", name: "Binance Coin", price: "$568.41", change: "+12.37", changePercent: "2.22%", isPositive: true },
    { symbol: "SOL", name: "Solana", price: "$139.92", change: "+6.47", changePercent: "4.85%", isPositive: true },
  ];
  
  const forex = [
    { symbol: "EUR/USD", name: "Euro / US Dollar", price: "1.0872", change: "+0.0023", changePercent: "0.21%", isPositive: true },
    { symbol: "GBP/USD", name: "Pound / US Dollar", price: "1.2706", change: "-0.0014", changePercent: "0.11%", isPositive: false },
    { symbol: "USD/JPY", name: "US Dollar / Yen", price: "154.63", change: "+0.42", changePercent: "0.27%", isPositive: true },
    { symbol: "USD/CAD", name: "US Dollar / CAD", price: "1.3642", change: "-0.0037", changePercent: "0.27%", isPositive: false },
  ];

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <CandlestickChart className="h-5 w-5" />
          Market Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="stocks">
          <TabsList className="mb-4">
            <TabsTrigger value="stocks">Stocks</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
            <TabsTrigger value="forex">Forex</TabsTrigger>
          </TabsList>
          
          <TabsContent value="stocks" className="space-y-0 divide-y divide-border">
            {stocks.map((item) => (
              <MarketItem key={item.symbol} {...item} />
            ))}
          </TabsContent>
          
          <TabsContent value="crypto" className="space-y-0 divide-y divide-border">
            {crypto.map((item) => (
              <MarketItem key={item.symbol} {...item} />
            ))}
          </TabsContent>
          
          <TabsContent value="forex" className="space-y-0 divide-y divide-border">
            {forex.map((item) => (
              <MarketItem key={item.symbol} {...item} />
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
