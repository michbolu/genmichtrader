
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export function RiskMetrics() {
  return (
    <Card className="col-span-1 md:col-span-3">
      <CardHeader>
        <CardTitle>Risk Metrics</CardTitle>
        <CardDescription>Summary of your current portfolio risk exposure</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-medium text-lg">Risk Exposure</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <div className="text-sm">VaR (95%)</div>
                <div className="text-sm text-destructive font-medium">$4,250.00</div>
              </div>
              <Progress value={42} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <div className="text-sm">Max Drawdown</div>
                <div className="text-sm text-destructive font-medium">12.5%</div>
              </div>
              <Progress value={25} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <div className="text-sm">Sharpe Ratio</div>
                <div className="text-sm text-primary font-medium">1.8</div>
              </div>
              <Progress value={65} className="h-2" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-medium text-lg">Diversification</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-sm">Stocks</div>
                <div className="flex items-center gap-2">
                  <div className="text-lg font-medium">45%</div>
                  <span className="text-xs text-green-500 flex items-center">
                    <ArrowUpIcon size={12} />
                    2.5%
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm">Bonds</div>
                <div className="flex items-center gap-2">
                  <div className="text-lg font-medium">15%</div>
                  <span className="text-xs text-red-500 flex items-center">
                    <ArrowDownIcon size={12} />
                    1.2%
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm">Crypto</div>
                <div className="flex items-center gap-2">
                  <div className="text-lg font-medium">30%</div>
                  <span className="text-xs text-green-500 flex items-center">
                    <ArrowUpIcon size={12} />
                    5.8%
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm">Forex</div>
                <div className="flex items-center gap-2">
                  <div className="text-lg font-medium">10%</div>
                  <span className="text-xs text-red-500 flex items-center">
                    <ArrowDownIcon size={12} />
                    0.8%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
