
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

interface BotStatusProps {
  status: 'active' | 'paused' | 'error';
  label: string;
}

const BotStatus = ({ status, label }: BotStatusProps) => {
  const statusMap = {
    active: { icon: <CheckCircle className="h-4 w-4 text-trading-profit" />, text: 'text-trading-profit' },
    paused: { icon: <Clock className="h-4 w-4 text-muted-foreground" />, text: 'text-muted-foreground' },
    error: { icon: <AlertCircle className="h-4 w-4 text-trading-loss" />, text: 'text-trading-loss' },
  };
  
  const { icon, text } = statusMap[status];
  
  return (
    <div className="flex items-center gap-1.5">
      {icon}
      <span className={`text-sm font-medium ${text}`}>{label}</span>
    </div>
  );
};

export function TradingBotSummary() {
  const bots = [
    { 
      id: 1, 
      name: "Momentum Trader", 
      description: "Tracks market momentum on major stocks", 
      status: 'active' as const, 
      lastTrade: "2 min ago",
      performance: "+4.6%",
      isProfit: true
    },
    { 
      id: 2, 
      name: "Crypto Arbitrage", 
      description: "Exploits price differences between exchanges", 
      status: 'paused' as const, 
      lastTrade: "3h ago",
      performance: "+1.8%",
      isProfit: true
    },
    { 
      id: 3, 
      name: "Forex Swing Trader", 
      description: "Identifies and trades on forex swings", 
      status: 'error' as const, 
      lastTrade: "1d ago",
      performance: "-0.7%",
      isProfit: false
    },
  ];

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          Trading Bots
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-0 divide-y divide-border">
          {bots.map((bot) => (
            <div key={bot.id} className="py-3 space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{bot.name}</h3>
                  <p className="text-sm text-muted-foreground">{bot.description}</p>
                </div>
                <BotStatus 
                  status={bot.status} 
                  label={bot.status === 'active' ? 'Active' : bot.status === 'paused' ? 'Paused' : 'Error'} 
                />
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="text-muted-foreground">Last trade: {bot.lastTrade}</div>
                <div className={bot.isProfit ? 'text-trading-profit' : 'text-trading-loss'}>
                  {bot.performance}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <Separator className="my-4" />
        
        <div className="flex justify-center">
          <Button variant="outline" className="w-full">
            Manage Trading Bots
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
