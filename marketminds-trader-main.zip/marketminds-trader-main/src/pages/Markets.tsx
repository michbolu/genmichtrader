
import { MainLayout } from "@/components/layout/MainLayout";
import { PriceChart } from "@/components/charts/PriceChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  CandlestickChart, 
  Search, 
  TrendingUp, 
  TrendingDown,
  Star,
  ArrowUpDown
} from "lucide-react";

const Markets = () => {
  const stockMarkets = [
    { symbol: "AAPL", name: "Apple Inc.", price: "$182.63", change: "+1.45", changePercent: "0.8%", volume: "32.5M", marketCap: "$2.87T", isPositive: true },
    { symbol: "MSFT", name: "Microsoft Corp.", price: "$402.75", change: "-3.21", changePercent: "0.79%", volume: "28.7M", marketCap: "$3.01T", isPositive: false },
    { symbol: "GOOGL", name: "Alphabet Inc.", price: "$162.08", change: "+0.87", changePercent: "0.54%", volume: "18.3M", marketCap: "$2.02T", isPositive: true },
    { symbol: "AMZN", name: "Amazon.com Inc.", price: "$178.15", change: "+2.31", changePercent: "1.31%", volume: "42.1M", marketCap: "$1.85T", isPositive: true },
    { symbol: "META", name: "Meta Platforms Inc.", price: "$478.22", change: "-5.42", changePercent: "1.12%", volume: "15.2M", marketCap: "$1.22T", isPositive: false },
    { symbol: "TSLA", name: "Tesla Inc.", price: "$175.21", change: "-2.34", changePercent: "1.32%", volume: "87.6M", marketCap: "$557.89B", isPositive: false },
    { symbol: "NVDA", name: "NVIDIA Corp.", price: "$103.23", change: "+1.87", changePercent: "1.84%", volume: "52.4M", marketCap: "$2.54T", isPositive: true },
    { symbol: "NFLX", name: "Netflix Inc.", price: "$602.78", change: "+12.45", changePercent: "2.11%", volume: "8.7M", marketCap: "$264.21B", isPositive: true },
  ];
  
  const cryptoMarkets = [
    { symbol: "BTC", name: "Bitcoin", price: "$61,245.32", change: "+1,256.78", changePercent: "2.1%", volume: "$28.4B", marketCap: "$1.2T", isPositive: true },
    { symbol: "ETH", name: "Ethereum", price: "$3,432.17", change: "-45.32", changePercent: "1.30%", volume: "$15.7B", marketCap: "$412.3B", isPositive: false },
    { symbol: "BNB", name: "Binance Coin", price: "$568.41", change: "+12.37", changePercent: "2.22%", volume: "$2.1B", marketCap: "$87.5B", isPositive: true },
    { symbol: "SOL", name: "Solana", price: "$139.92", change: "+6.47", changePercent: "4.85%", volume: "$4.5B", marketCap: "$61.2B", isPositive: true },
    { symbol: "XRP", name: "Ripple", price: "$0.5423", change: "-0.0134", changePercent: "2.41%", volume: "$1.7B", marketCap: "$29.8B", isPositive: false },
    { symbol: "DOT", name: "Polkadot", price: "$6.87", change: "+0.32", changePercent: "4.88%", volume: "$742.1M", marketCap: "$8.9B", isPositive: true },
    { symbol: "ADA", name: "Cardano", price: "$0.45", change: "+0.02", changePercent: "4.65%", volume: "$821.5M", marketCap: "$16.1B", isPositive: true },
    { symbol: "DOGE", name: "Dogecoin", price: "$0.1234", change: "-0.0032", changePercent: "2.53%", volume: "$912.3M", marketCap: "$17.8B", isPositive: false },
  ];
  
  const forexMarkets = [
    { symbol: "EUR/USD", name: "Euro / US Dollar", price: "1.0872", change: "+0.0023", changePercent: "0.21%", volume: "$124.3B", bid: "1.0871", ask: "1.0873", isPositive: true },
    { symbol: "GBP/USD", name: "Pound / US Dollar", price: "1.2706", change: "-0.0014", changePercent: "0.11%", volume: "$87.2B", bid: "1.2705", ask: "1.2707", isPositive: false },
    { symbol: "USD/JPY", name: "US Dollar / Yen", price: "154.63", change: "+0.42", changePercent: "0.27%", volume: "$98.5B", bid: "154.62", ask: "154.64", isPositive: true },
    { symbol: "USD/CAD", name: "US Dollar / CAD", price: "1.3642", change: "-0.0037", changePercent: "0.27%", volume: "$54.1B", bid: "1.3641", ask: "1.3643", isPositive: false },
    { symbol: "AUD/USD", name: "Australian Dollar / USD", price: "0.6612", change: "+0.0024", changePercent: "0.36%", volume: "$45.7B", bid: "0.6611", ask: "0.6613", isPositive: true },
    { symbol: "NZD/USD", name: "New Zealand Dollar / USD", price: "0.6038", change: "-0.0017", changePercent: "0.28%", volume: "$21.3B", bid: "0.6037", ask: "0.6039", isPositive: false },
    { symbol: "USD/CHF", name: "US Dollar / Swiss Franc", price: "0.9048", change: "+0.0019", changePercent: "0.21%", volume: "$32.8B", bid: "0.9047", ask: "0.9049", isPositive: true },
    { symbol: "EUR/GBP", name: "Euro / British Pound", price: "0.8557", change: "+0.0013", changePercent: "0.15%", volume: "$28.4B", bid: "0.8556", ask: "0.8558", isPositive: true },
  ];

  return (
    <MainLayout title="Markets">
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold">Markets</h2>
            <p className="text-muted-foreground">
              View and analyze real-time market data across multiple asset classes.
            </p>
          </div>
          <div className="flex items-center justify-end gap-4">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search markets..."
                className="pl-8 w-[250px]"
              />
            </div>
            <Button variant="outline" className="gap-1.5">
              <Star className="h-4 w-4" />
              Watchlist
            </Button>
          </div>
        </div>
        
        <PriceChart />
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <CandlestickChart className="h-5 w-5" />
              Market Data
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="stocks">
              <TabsList className="mb-4">
                <TabsTrigger value="stocks">Stocks</TabsTrigger>
                <TabsTrigger value="crypto">Crypto</TabsTrigger>
                <TabsTrigger value="forex">Forex</TabsTrigger>
              </TabsList>
              
              <TabsContent value="stocks">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[80px]">Symbol</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Change</TableHead>
                        <TableHead>
                          <div className="flex items-center gap-1">
                            Volume
                            <ArrowUpDown className="h-3.5 w-3.5" />
                          </div>
                        </TableHead>
                        <TableHead>
                          <div className="flex items-center gap-1">
                            Market Cap
                            <ArrowUpDown className="h-3.5 w-3.5" />
                          </div>
                        </TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stockMarkets.map((market) => (
                        <TableRow key={market.symbol}>
                          <TableCell className="font-medium">{market.symbol}</TableCell>
                          <TableCell>{market.name}</TableCell>
                          <TableCell>{market.price}</TableCell>
                          <TableCell>
                            <div className={`flex items-center gap-1 ${market.isPositive ? 'text-trading-profit' : 'text-trading-loss'}`}>
                              {market.isPositive ? 
                                <TrendingUp className="h-4 w-4" /> : 
                                <TrendingDown className="h-4 w-4" />
                              }
                              {market.change} ({market.changePercent})
                            </div>
                          </TableCell>
                          <TableCell>{market.volume}</TableCell>
                          <TableCell>{market.marketCap}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              <Star className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="crypto">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[80px]">Symbol</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Change</TableHead>
                        <TableHead>
                          <div className="flex items-center gap-1">
                            Volume (24h)
                            <ArrowUpDown className="h-3.5 w-3.5" />
                          </div>
                        </TableHead>
                        <TableHead>
                          <div className="flex items-center gap-1">
                            Market Cap
                            <ArrowUpDown className="h-3.5 w-3.5" />
                          </div>
                        </TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cryptoMarkets.map((market) => (
                        <TableRow key={market.symbol}>
                          <TableCell className="font-medium">{market.symbol}</TableCell>
                          <TableCell>{market.name}</TableCell>
                          <TableCell>{market.price}</TableCell>
                          <TableCell>
                            <div className={`flex items-center gap-1 ${market.isPositive ? 'text-trading-profit' : 'text-trading-loss'}`}>
                              {market.isPositive ? 
                                <TrendingUp className="h-4 w-4" /> : 
                                <TrendingDown className="h-4 w-4" />
                              }
                              {market.change} ({market.changePercent})
                            </div>
                          </TableCell>
                          <TableCell>{market.volume}</TableCell>
                          <TableCell>{market.marketCap}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              <Star className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="forex">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Symbol</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Change</TableHead>
                        <TableHead>Bid</TableHead>
                        <TableHead>Ask</TableHead>
                        <TableHead>
                          <div className="flex items-center gap-1">
                            Volume
                            <ArrowUpDown className="h-3.5 w-3.5" />
                          </div>
                        </TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {forexMarkets.map((market) => (
                        <TableRow key={market.symbol}>
                          <TableCell className="font-medium">{market.symbol}</TableCell>
                          <TableCell>{market.name}</TableCell>
                          <TableCell>{market.price}</TableCell>
                          <TableCell>
                            <div className={`flex items-center gap-1 ${market.isPositive ? 'text-trading-profit' : 'text-trading-loss'}`}>
                              {market.isPositive ? 
                                <TrendingUp className="h-4 w-4" /> : 
                                <TrendingDown className="h-4 w-4" />
                              }
                              {market.change} ({market.changePercent})
                            </div>
                          </TableCell>
                          <TableCell>{market.bid}</TableCell>
                          <TableCell>{market.ask}</TableCell>
                          <TableCell>{market.volume}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              <Star className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default Markets;
