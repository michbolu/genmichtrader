
import { MainLayout } from "@/components/layout/MainLayout";
import { TradingBotEditor } from "@/components/bots/TradingBotEditor";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Bot, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Plus, 
  Play, 
  Pause, 
  Settings
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

const Bots = () => {
  const tradingBots = [
    { 
      id: 1, 
      name: "Momentum Trader", 
      asset: "BTC/USD",
      type: "Momentum",
      status: 'active', 
      lastTrade: "2 min ago",
      profit: "+$745.23",
      performance: "+4.6%",
      tradesWon: 23,
      tradesLost: 7
    },
    { 
      id: 2, 
      name: "Crypto Arbitrage", 
      asset: "Multi-Exchange",
      type: "Arbitrage",
      status: 'paused', 
      lastTrade: "3h ago",
      profit: "+$246.78",
      performance: "+1.8%",
      tradesWon: 42,
      tradesLost: 19
    },
    { 
      id: 3, 
      name: "Forex Swing Trader", 
      asset: "EUR/USD",
      type: "Swing",
      status: 'error', 
      lastTrade: "1d ago",
      profit: "-$89.45",
      performance: "-0.7%",
      tradesWon: 14,
      tradesLost: 16
    },
    { 
      id: 4, 
      name: "Tech Stock Scanner", 
      asset: "NASDAQ:TECH",
      type: "Mean Reversion",
      status: 'active', 
      lastTrade: "14 min ago",
      profit: "+$1,367.92",
      performance: "+7.2%",
      tradesWon: 34,
      tradesLost: 12
    },
    { 
      id: 5, 
      name: "Gold Trend Follower", 
      asset: "XAUUSD",
      type: "Trend Following",
      status: 'active', 
      lastTrade: "37 min ago",
      profit: "+$324.56",
      performance: "+2.1%",
      tradesWon: 17,
      tradesLost: 9
    },
  ];

  return (
    <MainLayout title="Trading Bots">
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold">AI Trading Bots</h2>
            <p className="text-muted-foreground">
              Create and manage automated trading strategies powered by artificial intelligence.
            </p>
          </div>
          <div className="flex items-center justify-end">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create New Bot
            </Button>
          </div>
        </div>
        
        <TradingBotEditor />
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              Your Trading Bots
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">Name</TableHead>
                    <TableHead>Asset/Market</TableHead>
                    <TableHead>Strategy</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Trade</TableHead>
                    <TableHead>Performance</TableHead>
                    <TableHead>Win Rate</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tradingBots.map((bot) => (
                    <TableRow key={bot.id}>
                      <TableCell className="font-medium">{bot.name}</TableCell>
                      <TableCell>{bot.asset}</TableCell>
                      <TableCell>{bot.type}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          {bot.status === 'active' ? (
                            <Badge variant="outline" className="bg-trading-profit/10 text-trading-profit border-trading-profit/20 flex gap-1 items-center">
                              <CheckCircle className="h-3 w-3" />
                              Active
                            </Badge>
                          ) : bot.status === 'paused' ? (
                            <Badge variant="outline" className="bg-muted text-muted-foreground flex gap-1 items-center">
                              <Clock className="h-3 w-3" />
                              Paused
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-trading-loss/10 text-trading-loss border-trading-loss/20 flex gap-1 items-center">
                              <AlertCircle className="h-3 w-3" />
                              Error
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{bot.lastTrade}</TableCell>
                      <TableCell className={bot.performance.startsWith('+') ? 'text-trading-profit' : 'text-trading-loss'}>
                        {bot.profit} ({bot.performance})
                      </TableCell>
                      <TableCell>
                        {((bot.tradesWon / (bot.tradesWon + bot.tradesLost)) * 100).toFixed(1)}%
                        <div className="text-xs text-muted-foreground">
                          {bot.tradesWon}W / {bot.tradesLost}L
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Settings className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                          >
                            {bot.status === 'active' ? (
                              <Pause className="h-4 w-4" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default Bots;
