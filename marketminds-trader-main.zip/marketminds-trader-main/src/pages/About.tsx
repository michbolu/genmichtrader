
import { Clock, Users, Award, BarChart4, Zap, Globe } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const About = () => {
  return (
    <MainLayout title="About Us">
      <div className="max-w-5xl mx-auto space-y-12">
        {/* Hero section */}
        <section className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">Our Story</h1>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto">
            Gen.Michael is a cutting-edge AI-powered trading platform designed to revolutionize how traders interact with financial markets.
          </p>
        </section>

        {/* Mission statement */}
        <Card>
          <CardContent className="pt-6">
            <div className="bg-muted/30 p-6 rounded-lg border border-border">
              <blockquote className="text-xl italic font-medium text-center">
                "Our mission is to democratize algorithmic trading by making powerful AI tools accessible to everyone."
              </blockquote>
            </div>
          </CardContent>
        </Card>

        {/* Timeline */}
        <section>
          <h2 className="text-2xl font-bold mb-6">Our Journey</h2>
          <div className="space-y-8">
            <TimelineItem 
              year="2018" 
              title="The Beginning" 
              description="Founded by a team of financial analysts and AI researchers with a vision to transform trading through artificial intelligence."
              icon={<Clock size={24} />}
            />
            <TimelineItem 
              year="2020" 
              title="First AI Models" 
              description="Launched our first generation of machine learning models capable of analyzing market patterns and predicting trends."
              icon={<BarChart4 size={24} />}
            />
            <TimelineItem 
              year="2021" 
              title="Platform Launch" 
              description="Released the Gen.Michael platform with real-time market data and automated trading capabilities."
              icon={<Zap size={24} />}
            />
            <TimelineItem 
              year="2023" 
              title="Global Expansion" 
              description="Expanded our services to support multiple asset classes and markets across the globe."
              icon={<Globe size={24} />}
            />
          </div>
        </section>

        {/* Team section */}
        <section>
          <h2 className="text-2xl font-bold mb-6">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TeamMember 
              name="Dr. Alex Chen" 
              role="Founder & CEO" 
              bio="Former quantitative analyst with a Ph.D. in Machine Learning from MIT." 
            />
            <TeamMember 
              name="Sophia Rodriguez" 
              role="CTO" 
              bio="AI researcher with expertise in predictive modeling and neural networks." 
            />
            <TeamMember 
              name="Marcus Williams" 
              role="Head of Trading" 
              bio="20+ years experience in institutional trading across multiple asset classes." 
            />
          </div>
        </section>

        {/* Key features */}
        <section>
          <h2 className="text-2xl font-bold mb-6">What Sets Us Apart</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FeatureCard 
              title="Advanced AI Technology" 
              description="Our proprietary algorithms analyze market data and execute trades with precision." 
              icon={<Zap className="h-12 w-12 text-primary" />}
            />
            <FeatureCard 
              title="Risk Management" 
              description="Sophisticated risk assessment tools to protect your investments." 
              icon={<Award className="h-12 w-12 text-primary" />}
            />
          </div>
        </section>
      </div>
    </MainLayout>
  );
};

// Helper components
const TimelineItem = ({ year, title, description, icon }) => (
  <div className="flex">
    <div className="flex flex-col items-center mr-4">
      <div className="bg-primary p-2 rounded-full">
        {icon}
      </div>
      <div className="w-px h-full bg-border mt-2"></div>
    </div>
    <div className="pb-8">
      <span className="text-primary font-bold">{year}</span>
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  </div>
);

const TeamMember = ({ name, role, bio }) => (
  <Card className="overflow-hidden">
    <div className="h-40 bg-muted flex items-center justify-center">
      <Users size={64} className="text-muted-foreground/50" />
    </div>
    <CardHeader>
      <CardTitle>{name}</CardTitle>
      <div className="text-primary font-medium">{role}</div>
    </CardHeader>
    <CardContent>
      <p className="text-muted-foreground">{bio}</p>
    </CardContent>
  </Card>
);

const FeatureCard = ({ title, description, icon }) => (
  <Card>
    <CardContent className="pt-6">
      <div className="flex flex-col items-center text-center space-y-4">
        {icon}
        <h3 className="text-xl font-semibold">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </div>
    </CardContent>
  </Card>
);

export default About;
