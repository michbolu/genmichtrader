
import { MainLayout } from "@/components/layout/MainLayout";
import { PriceChart } from "@/components/charts/PriceChart";
import { MarketOverview } from "@/components/dashboard/MarketOverview";
import { PortfolioSummary } from "@/components/dashboard/PortfolioSummary";
import { TradingBotSummary } from "@/components/dashboard/TradingBotSummary";
import { RiskMetrics } from "@/components/dashboard/RiskMetrics";

const Index = () => {
  return (
    <MainLayout title="Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <PriceChart />
        <MarketOverview />
        <PortfolioSummary />
        <TradingBotSummary />
        <RiskMetrics />
      </div>
    </MainLayout>
  );
};

export default Index;
